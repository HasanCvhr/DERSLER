/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.studentinformations;
import java.util.Scanner;
/**
 *
 * @author hceva
 */

/**
 * Öğrenci bilgilerini yöneten program
 */
public class StudentInformations {//StudentInformations adında bir public class oluşturduk.
    static Scanner scanner = new Scanner(System.in);
    static String[] studentNumbers;
    static String[] studentNames;
    static double[] finalGrades;
    static double[] midtermGrades;
    static double[] averages;
    static int studentCount;

    public static void main(String[] args) {
        System.out.print("Please enter the number of students: ");
        studentCount = scanner.nextInt();
        scanner.nextLine(); // nextInt() sonrası satır sonu karakterini temizleme
        studentNumbers = new String[studentCount];
        studentNames = new String[studentCount];
        midtermGrades = new double[studentCount];
        finalGrades = new double[studentCount];
        averages = new double[studentCount];

        while (true) {
            displayMenu();
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1: getStudentInfo(); break;
                case 2: displayAllStudents(); break;
                case 3: calculateAverages(); break;
                case 4: displayFailingStudents(); break;
                case 5: displayAboveAverage(); break;
                case 6: countFailingGrades(); break;
                case 7: findHighestGrade(); break;
                case 8: findLowestGrade(); break;
                case 9: sortAndDisplay(); break;
                case 0: System.out.println("Exiting the menu..."); return;
                default: System.out.println("Wrong choice, try again!");
            }
        }
    }

    public static void displayMenu() {
        System.out.println("-Student Informations-");
        System.out.println("1. Enter student information");
        System.out.println("2. Display all students");
        System.out.println("3. Calculate averages");
        System.out.println("4. Display failing students");
        System.out.println("5. Display above average students");
        System.out.println("6. Count failing grades");
        System.out.println("7. Find highest grade");
        System.out.println("8. Find lowest grade");
        System.out.println("9. Sort and display by grades");
        System.out.println("0. Exit");
        System.out.print("Enter your choice: ");
    }

    public static void getStudentInfo() {
        for (int i = 0; i < studentCount; i++) {
            System.out.println("Student " + (i + 1));
            System.out.print("Enter student number: ");
            studentNumbers[i] = scanner.nextLine();
            System.out.print("Enter student name: ");
            studentNames[i] = scanner.nextLine();
            System.out.print("Enter midterm grade: ");
            midtermGrades[i] = scanner.nextDouble();
            System.out.print("Enter final grade: ");
            finalGrades[i] = scanner.nextDouble();
            scanner.nextLine(); // nextDouble sonrası satır sonu temizleme
        }
    }

    

    public static void calculateAverages() {
        for (int i = 0; i < studentCount; i++) {
            averages[i] = (midtermGrades[i] * 0.4) + (finalGrades[i] * 0.6);
        
        }
    for (int i = 0; i < studentCount; i++) {
            System.out.printf("No: %s, Name: %s, Midterm: %.2f, Final: %.2f, Average: %.2f%n", 
                studentNumbers[i], studentNames[i], midtermGrades[i], finalGrades[i], averages[i]);
        
        }
    }

    public static void displayAllStudents() {
        for (int i = 0; i < studentCount; i++) {
            System.out.printf("No: %s, Name: %s, Midterm: %.2f, Final: %.2f, Average: %.2f%n", 
                studentNumbers[i], studentNames[i], midtermGrades[i], finalGrades[i], averages[i]);
        }
    }

    public static void displayFailingStudents() {
        calculateAverages();
        for (int i = 0; i < studentCount; i++) {
            if (averages[i] < 60) {
                System.out.printf("No: %s, Name: %s, Average: %.2f%n", studentNumbers[i], studentNames[i], averages[i]);
            }
        }
    }

    public static void displayAboveAverage() {
        calculateAverages();
        double total = 0;
        for (double avg : averages) total += avg;
        double classAverage = total / studentCount;

        for (int i = 0; i < studentCount; i++) {
            if (averages[i] > classAverage) {
                System.out.printf("No: %s, Name: %s, Average: %.2f%n", studentNumbers[i], studentNames[i], averages[i]);
            }
        }
    }

    public static void countFailingGrades() {
        calculateAverages();
        int count = 0;
        for (double avg : averages) {
            if (avg < 60) count++;
        }
        System.out.println("Number of failing grades: " + count);
    }

    public static void findHighestGrade() {
        calculateAverages();
        double max = -1;
        int index = -1;
        for (int i = 0; i < studentCount; i++) {
            if (averages[i] > max) {
                max = averages[i];
                index = i;
            }
        }
        System.out.printf("Highest Grade: No: %s, Name: %s, Average: %.2f%n", studentNumbers[index], studentNames[index], max);
    }

    public static void findLowestGrade() {
        calculateAverages();
        double min = 101;
        int index = -1;
        for (int i = 0; i < studentCount; i++) {
            if (averages[i] < min) {
                min = averages[i];
                index = i;
            }
        }
        System.out.printf("Lowest Grade: No: %s, Name: %s, Average: %.2f%n", studentNumbers[index], studentNames[index], min);
    }

    public static void sortAndDisplay() {
        calculateAverages();
        for (int i = 0; i < studentCount - 1; i++) {
            for (int j = 0; j < studentCount - i - 1; j++) {
                if (averages[j] > averages[j + 1]) {
                    swap(j, j + 1);
                }
            }
        
        }
        for (int i = 0; i < studentCount; i++) {
            System.out.printf("No: %s, Name: %s, Midterm: %.2f, Final: %.2f, Average: %.2f%n", 
                studentNumbers[i], studentNames[i], midtermGrades[i], finalGrades[i], averages[i]);
        
        }
    
    }

    public static void swap(int i, int j) {
        double tempAvg = averages[i];
        averages[i] = averages[j];
        averages[j] = tempAvg;

        String tempNum = studentNumbers[i];
        studentNumbers[i] = studentNumbers[j];
        studentNumbers[j] = tempNum;

        String tempName = studentNames[i];
        studentNames[i] = studentNames[j];
        studentNames[j] = tempName;
    }
}

    