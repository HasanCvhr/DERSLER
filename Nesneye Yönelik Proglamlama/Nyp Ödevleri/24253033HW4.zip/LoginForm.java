
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LoginForm extends JFrame {
    public LoginForm() {
        setTitle("Giriş Yap");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel userLabel = new JLabel("Kullanıcı Adı:");
        JTextField userField = new JTextField(15);

        JLabel passLabel = new JLabel("Şifre:");
        JPasswordField passField = new JPasswordField(15);

        JButton loginButton = new JButton("Giriş");
        JButton registerButton = new JButton("Kayıt Ol");

        JPanel panel = new JPanel(new GridLayout(3, 2));
        panel.add(userLabel);
        panel.add(userField);
        panel.add(passLabel);
        panel.add(passField);
        panel.add(loginButton);
        panel.add(registerButton);

        add(panel);

        loginButton.addActionListener(e -> {
            dispose();
            new PizzaOrderForm();
        });

        registerButton.addActionListener(e -> {
            dispose();
            new RegisterForm();
        });

        setVisible(true);
    }
}
