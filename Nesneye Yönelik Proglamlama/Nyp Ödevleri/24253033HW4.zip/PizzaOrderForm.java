
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class PizzaOrderForm extends JFrame {
    public PizzaOrderForm() {
        setTitle("Pizza Sipariş Uygulaması");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        String[] hamurOptions = { "Klasik Hamur", "İnce Hamur", "Dubleks çift kat peynir" };
        JComboBox<String> hamurCombo = new JComboBox<>(hamurOptions);

        String[] pizzaOptions = { "Extravaganza", "Karışık", "Pizza Mexicano", "Italiano", "Turkish pizza", "Favorite Three" };
        JComboBox<String> pizzaCombo = new JComboBox<>(pizzaOptions);

        String[] sizeOptions = { "Küçük", "Orta", "Büyük" };
        JComboBox<String> sizeCombo = new JComboBox<>(sizeOptions);

        JButton addToCart = new JButton("Sepete Ekle");
        JButton finishOrder = new JButton("Siparişi Tamamla");

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 2));
        panel.add(new JLabel("Hamur Seçimi:"));
        panel.add(hamurCombo);
        panel.add(new JLabel("Pizza Seçimi:"));
        panel.add(pizzaCombo);
        panel.add(new JLabel("Boyut Seçimi:"));
        panel.add(sizeCombo);
        panel.add(addToCart);
        panel.add(finishOrder);

        add(panel);

        addToCart.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Ürün sepete eklendi!");
        });

        finishOrder.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Toplam ücret: 250 TL (örnek)");
        });

        setVisible(true);
    }
}
