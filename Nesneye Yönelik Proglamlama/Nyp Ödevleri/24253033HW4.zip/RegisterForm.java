
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class RegisterForm extends JFrame {
    public RegisterForm() {
        setTitle("Kayıt Ol");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel userLabel = new JLabel("Yeni Kullanıcı Adı:");
        JTextField userField = new JTextField(15);

        JLabel passLabel = new JLabel("Şifre:");
        JPasswordField passField = new JPasswordField(15);

        JButton registerButton = new JButton("Kayıt Ol");

        JPanel panel = new JPanel(new GridLayout(3, 2));
        panel.add(userLabel);
        panel.add(userField);
        panel.add(passLabel);
        panel.add(passField);
        panel.add(new JLabel(""));
        panel.add(registerButton);

        add(panel);

        registerButton.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Kayıt başarılı! Giriş ekranına yönlendiriliyorsunuz.");
            dispose();
            new LoginForm();
        });

        setVisible(true);
    }
}
