/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.studentinformationsnew;

/**
 *
 * @author hceva
 */
import java.util.ArrayList;
import java.util.Comparator;
import java.util.*;

public class StudentInformationsNew {
    public static void main(String[] args) {// main fonksiyonumuzu tanımladık.
        ArrayList<Student> students = new ArrayList<>();//yeni bir arraylist oluşturduk.
        Scanner scanner = new Scanner(System.in);// kullanıcıdan menü işlemi için bir sayı alıcaz.
        int choice;// bu sayıyı choice değişkeniyle temsil ediyoruz.

        do {//menü ekranımızı görüntüledik.
            System.out.println("\nMenu:");
            System.out.println("1. Add Student");// öğrenci ekleme
            System.out.println("2. Display all Students");// girilen öğrencileri görüntüleme 
            System.out.println("3. Calculate Exam Averages");//sınav ortalaması hesaplama
            System.out.println("4. Grades Below 60");// 60 ın altında kalan notlar
            System.out.println("5. Students Above Average");// ortalamanın üstünde kalan öğrenciler 
            System.out.println("6. Count Grades Below 60");// 60 ın altında kalan öğrenci sayısı
            System.out.println("7. Highest Exam Grade");// en yüksek sınav notu
            System.out.println("8. Sort and Display Students");// öğrencileri görüntüleme
            System.out.println("0. Exit the menu");
            System.out.print("Choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Yeni satır karakterini tüket

            switch (choice) {
                case 1:
                    addStudent(students, scanner); // Öğrenci ekleme metodumuz
                    break;
                case 2:
                    viewStudents(students); // Öğrencileri görüntüleme metodumuz
                    break;
                case 3:
                    calculateExamAverages(students); // Sınav ortalamalarını hesaplama metodumuz
                    break;
                case 4:
                    gradesBelowSixty(students); // 60'ın altındaki notları gösteren metodumuz
                    break;
                case 5:
                    studentsAboveAverage(students); // Ortalamanın üstündeki öğrencileri gösteren metodumuz
                    break;
                case 6:
                    countGradesBelowSixty(students); // 60'ın altındaki not sayısını gösteren metodumuz
                    break;
                case 7:
                    highestExamGrade(students); // En yüksek sınav notunu gösteren metodumuz
                    break;
                case 8:
                    sortStudents(students); // Öğrencileri sıralayan metodumuz.
                    break;
                case 0:
                    System.out.println("Exiting the menu...");
                    break;
                default:
                    System.out.println("Wrong choice,Please try again !");
            }
        } while (choice != 0);// 0 a basınca çıkıyoruz.

        scanner.close();
    }


    // Öğrencileri görüntüleme metodu
    public static void addStudent(ArrayList<Student> students, Scanner scanner) {
        System.out.print("Student ID: ");// öğrenci numarasını alıyoruz.
        String id = scanner.nextLine();
        System.out.print("Student Name: ");// öğrenci ismini alıyoruz.
        String name = scanner.nextLine();
        Student student = new Student(id, name);// yeni bir object oluşturuyoruz.

      // öğrenci derslerini eklemek için while döngüsü açıyoruz.
        while (true) {
            System.out.print("Course Name (Enter 'q' to quit): ");
            String courseName = scanner.nextLine();
            if (compare(courseName, "q")) { // q girene kadar kullanıcıdan ders adı, vize ve final notları alınıyor.
                break;
            }
            System.out.print("Midterm Grade: ");//vize notu giriliyor
            int midterm = scanner.nextInt();
            System.out.print("Final Grade: ");// final notu giriliyor.
            int finalGrade = scanner.nextInt();
            scanner.nextLine(); // yeni satır karakteri tüketmek için.

            student.addCourse(new Course(courseName, midterm, finalGrade)); // Add course
        }

        students.add(student); // Add student to the list
    }

    // Öğrencileri gösteren metodumuz
    public static void viewStudents(ArrayList<Student> students) {
        for (Student student : students) {// listemize eklediğimiz öğrencileri toString ile ekrana yazdırıyoruz.
            System.out.println(student.toString());
        }
    }

    //  Sınav ortalamalarını hesaplama metodumuz
    public static void calculateExamAverages(ArrayList<Student> students) {
        for (Student student : students) {
            System.out.println(student.toString()); // öğrenci bilgileri ve ortalamalar ekrana yazdırılıyor.
        }
    }

    //  60'ın altındaki sınav sonuçlarını görüntüleme metodumuz
    public static void gradesBelowSixty(ArrayList<Student> students) {// listeden ortalama 60 ın aşağısında olan kişileri bilgileriyle ekrana yazdırıyoruz.
        for (Student student : students) {
            for (Course course : student.getCourses()) {
                if (course.getAverageGrade() < 60) {
                    System.out.println(student.getStudentId() + " - " + student.getStudentName() + " - " + course.toString());
                }
            }
        }
    }

    // Ortalamanın üstünde not alan öğrencileri görüntüleme metodumuz
    public static void studentsAboveAverage(ArrayList<Student> students) {//// listeden ortalama 60 ın yukarısında olan kişileri bilgileriyle ekrana yazdırıyoruz.
        for (Student student : students) {
            for (Course course : student.getCourses()) {
                if (course.getAverageGrade() > student.getStudentAverageGrade()) {
                    System.out.println(student.getStudentId() + " - " + student.getStudentName() + " - " + course.toString());
                }
            }
        }
    }

    // 60'ın altındaki sınav sonuçlarının sayısını hesaplama metodumuz
    public static void countGradesBelowSixty(ArrayList<Student> students) {
        int count = 0;
        for (Student student : students) {// listedeki öğrencilerden ortalaması 60 ın aşağısında olan ders sayısını hesaplıyoruz.
            for (Course course : student.getCourses()) {
                if (course.getAverageGrade() < 60) {
                    count++;
                }
            }
        }
        System.out.println("Total number of grades below 60: " + count);
    }

    // En yüksek sınav sonucunu bulma metodumuz
    public static void highestExamGrade(ArrayList<Student> students) {
        for (Student student : students) {
            Course highest = null;
            for (Course course : student.getCourses()) {
                if (highest == null || course.getAverageGrade() > highest.getAverageGrade()) {
                    highest = course;
                }
            }
            if (highest != null) {
                System.out.println(student.getStudentId() + " - " + student.getStudentName() + " - " + highest.toString());
            }
        }
    }

    // Öğrencileri ortalamalarına göre sıralama metodumuz
    public static void sortStudents(ArrayList<Student> students) {
        students.sort(Comparator.comparingDouble(Student::getStudentAverageGrade));
        for (Student student : students) { // öğrencileri ortalamalarına göre sıralıyoruz.
            System.out.println(student.toString());
        }
    }

    // String karşılatırma metodumuz
    public static boolean compare(String str1, String str2) {
        if (str1.length() != str2.length()) {// 1.ve 2. stringlerimiz eşit değilse false dönüyor
            return false;
        }
        for (int i = 0; i < str1.length(); i++) {//1.stringimizin uzunluğu kadar for döngümüz döncek
            if (Character.toLowerCase(str1.charAt(i)) != Character.toLowerCase(str2.charAt(i))) {
                return false;//
            }
        }
        return true;
    }
}

