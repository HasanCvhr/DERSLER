/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.studentinformationsnew;

/**
 *
 * @author hceva
 */
public class Course {//Ders bilgileri için bir sınıf oluşturduk.Bütün değişkenleri private tanımladık.
    private String courseName; // Dersin adı
    private int midtermGrade;   // Vize notu
    private int finalGrade;     // Final notu
    private double averageGrade; // Ortalama not

    // Ders sınıfımızın constructor'tırını oluşturduk.
    public Course(String courseName, int midtermGrade, int finalGrade) {// 3 tane parametre aldık.
        this.courseName=courseName;   //this kullanarak metoda gelen değerle sınıf içindeki değerin karışmasını önledik.
        this.midtermGrade = midtermGrade;
        this.finalGrade = finalGrade;
        this.averageGrade = midtermGrade * 0.4 + finalGrade * 0.6; // Ortalama hesaplamamızı verilen orana göre ayarladık.
    }

    // Get  metotlarımız 
    
    /**
     * @return the courseName
     */
    public String getCourseName() {
        return courseName;
    }

    /**
     * @return the midtermGrade
     */
    public int getMidtermGrade() {
        return midtermGrade;
    }

    /**
     * @return the finalGrade
     */
    public int getFinalGrade() {
        return finalGrade;
    }

    /**
     * @return the averageGrade
     */
    public double getAverageGrade() {
        return averageGrade;
    }

public String toString() {// Ders bilgilerini string olarak döndüren metotumuz toString
        return getCourseName() + " (Midterm: " + getMidtermGrade() + ", Final: " + getFinalGrade() + ", Average: " + getAverageGrade() + ")";
    }
}