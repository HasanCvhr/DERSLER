/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.studentinformationsnew;

/**
 *
 * @author hceva
 */
import java.util.ArrayList;

public class Student {//Öğrenci bilgileri için bir sınıf oluşturduk,değişkenlerimizi ve arraylistimizi private olarak tanımladık.
    private String studentId;           // Öğrencinin numarası
    private String studentName;         // Öğrencinin adı
    private ArrayList<Course> courses; // Ders listesi (arraylist olarak oluşturduk).
    private double studentAverageGrade; // Öğrenci ortalama notu

    // Öğrenci sınıfının constructor'tırını oluşturduk.
    public Student(String studentId, String studentName) {// 2 adet parametre aldık.
        this.studentId = studentId;//this kullanarak metoda gelen değerle sınıf içindeki değerin karışmasını önledik.
        this.studentName = studentName;
        this.courses = new ArrayList<>();
        this.studentAverageGrade = 0.0;// ortalamanın default değerini 0 olarak belirledik.
    }

    // Öğrenciye ders ekleme metodumuz.
    public void addCourse(Course course) {
        getCourses().add(course);
        calculateAverageGrade(); // Ortalama hesaplama metodumuzu çağırdık.
    }

    // Öğrencinin ortalama notunu hesaplama metodumuz.
    private void calculateAverageGrade() {
        double total = 0.0;
        for (Course course : getCourses()) {
            total += course.getAverageGrade();
        }
        studentAverageGrade = getCourses().isEmpty() ? 0.0 : total / getCourses().size(); // Ortalama hesaplama
    }

    // Get metotlarımız 

    /**
     * @return the studentId
     */
    public String getStudentId() {
        return studentId;
    }

    /**
     * @return the studentName
     */
    public String getStudentName() {
        return studentName;
    }

    /**
     * @return the courses
     */
    public ArrayList<Course> getCourses() {
        return courses;
    }

    /**
     * @return the studentAverageGrade
     */
    public double getStudentAverageGrade() {
        return studentAverageGrade;
    }
    
    // Öğrenci bilgilerini string olarak döndüren metot toString metodumuz.
    
    public String toString() {
    String result = "ID: " + studentId + ", Name: " + studentName + ", Courses: ";
    for (Course course : courses) {
        result += course.toString() + ", ";
    }
    result += "Average: " + studentAverageGrade;
    return result;
}
}