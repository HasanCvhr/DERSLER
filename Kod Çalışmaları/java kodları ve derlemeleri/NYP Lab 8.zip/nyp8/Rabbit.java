import java.util.Random;

public class Rabbit extends Animal {
    
    public Rabbit (int number){
        super("R", number);
    }
    
    public void move() {
        Random rnd = new Random();
        
        int randomNumber = rnd.nextInt(1,11);
        
        if (randomNumber >=1 && randomNumber <=2) {
            //sleep
        } else if (randomNumber >=3 && randomNumber <=4) {
            position+=9;
        } else if (randomNumber == 5) {
            position-=12;
        } else if (randomNumber >= 6 && randomNumber <= 8) {
            position += 1;
        } else {
            position -= 2;
        }
        
        if (position < 0) {
            position = 0;
        }
    }
    
}
