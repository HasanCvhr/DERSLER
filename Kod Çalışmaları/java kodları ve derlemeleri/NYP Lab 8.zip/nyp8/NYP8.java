import java.util.ArrayList;
import java.util.Random;

public class NYP8 {

    public static void main(String[] args) {
        
        int tcount = 4;
        int rcount = 5;
        
        Tortoise[] tArray = new Tortoise[tcount];
        Rabbit[] rArray = new Rabbit[rcount];
        
        for (int i = 0; i < tArray.length ; i++) {
            tArray[i] = new Tortoise(i);
        }
        
        for (int i = 0; i < rArray.length ; i++) {
            rArray[i] = new Rabbit(i);
        }
        
        boolean raceFlag = false;
        
        ArrayList<Tortoise> winnerT = new ArrayList<>();
        ArrayList<Rabbit> winnerR = new ArrayList<>();
       
        while (!raceFlag) {
            for (int i = 0; i < tArray.length ; i++) {
                tArray[i].move();
                if (tArray[i].getPosition() >=70) {
                    raceFlag = true;
                    winnerT.add(tArray[i]);
                }
            }
        
            for (int i = 0; i < rArray.length ; i++) {
                rArray[i].move();
                if (rArray[i].getPosition() >= 70) {
                    raceFlag = true;
                    winnerR.add(rArray[i]);
                }
            }
        }
        
        for (int i = 0; i < tArray.length ; i++) {
            tArray[i].displayPosition();
        }
        
        for (int i = 0; i < rArray.length ; i++) {
            rArray[i].displayPosition();
        }
        
        System.out.println("---- Kazananlar ----");
        
        for (int i = 0; i<winnerT.size();i++) {
            System.out.println(winnerT.get(i));
        }
        for (int i = 0; i<winnerR.size();i++) {
            System.out.println(winnerR.get(i));
        }
        
    }
}
