
public class Animal {
    
   protected int position;
   protected String name;
   
   public Animal(String hayvan, int number) {
       this.name = hayvan+number; // T2, R5
       
   }
   
   protected void move() {
       System.out.println("Bu methodu özelleştir.");
   }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    
    public void displayPosition() {
        String line = "";
        
        for (int i = 0 ; i < position; i++ ) {
            line+= " ";
        }
        line += name;
        
        
        
        System.out.println(line);
        
    }
    
    
    public String toString() {
        return name;
    }

   
}
