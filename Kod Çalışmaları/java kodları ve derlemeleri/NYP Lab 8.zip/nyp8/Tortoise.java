import java.util.Random;

public class Tortoise extends Animal {
    
    public Tortoise(int number) {
        super("T" , number);
               
    }
    
    public void move() {
        Random rnd = new Random();
        
        int randomNumber = rnd.nextInt(1,11);
        
        if (1 <= randomNumber && randomNumber <= 5) {
            position+=3;
        } else if (6 <= randomNumber && randomNumber <=7) {
            position-=6;
            
            if (position < 0) {
                position = 0;
            }
                    
        } else {
            position+=1;
        }
                
        
    }
    
    
}
